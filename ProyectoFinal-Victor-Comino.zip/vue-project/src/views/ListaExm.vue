<script setup>
import { ref } from 'vue';

const examen = ref([]);

const examenRecogido = JSON.parse(localStorage.getItem('Examen'));
examen.value = examenRecogido;

</script>

<template>
    <main>
        <div>
            <h1>Lista de Exámenes</h1>
            <ul>
                <li v-for="exm in examen" :key="exm.id">
                    <strong>{{ exm.titulo }}</strong> - {{ exm.fecha }}
                </li>
            </ul>
        </div>
    </main>
</template>

<style scoped>
main {
    background-color: beige;
}

h1 {
    margin: 0;
    margin-left: 1rem;
}

p {
    margin: 0;
}

form {
    padding: 1rem;
}
</style>