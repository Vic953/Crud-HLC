<script setup>
import router from '@/router'
import { ref, defineEmits } from 'vue'

const emits = defineEmits(['datosActualizados'])

const nombre = ref('')
const contraseña = ref('')
const rol = ref('')

/* 
const guardarDatos = function () {
  localStorage.setItem("nombre", nombre.value);
  localStorage.setItem("contra", contraseña.value);
  localStorage.setItem("rol", contraseña.value);
  emits("datosActualizados");
  router.push("/");
} */

const comprobarSesion = function () {
  fetch('../public/datos.json')
    .then((reponse) => reponse.json())
    .then(function (data) {
      data.forEach((x) => {
        const valido = data.find(
          (x) => x.nombre == nombre.value && x.contraseña == contraseña.value && x.rol  == rol.value)
        if (valido) {
          localStorage.setItem('sesionN', nombre.value)
          localStorage.setItem('sesionC', contraseña.value)
          localStorage.setItem('sesionR', rol.value)
          emits('datosActualizados')

          router.push('/home')
          
        } else {
          console.log('Error ERROR ¡ERROR!')
        }
      })
    })
}
</script>

<template>
  <main>
    <div class="contentLog">
      <div id="content">
        <h1>Login:</h1>
        <div class="bott">
          <input placeholder="nombre" v-model="nombre" />
          <br />
          <input placeholder="contraseña" v-model="contraseña" />
          <br />
        </div>
        <div class="select">
          <select v-model="rol">
            <option value="alumno">alumno</option>
            <option value="profesor">profesor</option>
          </select>
          <br />
          <button @click="comprobarSesion">Iniciar sesión</button>
        </div>
      </div>
    </div>
  </main>
</template>

<style scoped>
.contentLog {
  display: flex;
  margin: 15px;
  align-items: center;
  justify-content: center;
  height: 80vh;
}

.select {
  display: grid;

}

.bott {
  margin: 5px;
}

input {
  margin: 5px;
}

button {
  transition: 0.4s;
  cursor: pointer;
  background-color: black;
  color: white;
}

button:active {
  background-color: white;
  color: black;
}

#content {
  border: 1px solid salmon;
  padding: 15px;
  border-radius: 15px;
}
</style>
