<script setup>
import { ref } from 'vue';

//Variables 
const preguntas = ref([]);
const mostrar = ref('false');

const categorias = JSON.parse(localStorage.getItem("Categorias"));

const listaPreguntasGuardadas = JSON.parse(localStorage.getItem("Preguntas"));
if (listaPreguntasGuardadas) {
    preguntas.value = listaPreguntasGuardadas;
}

const nuevaPreg = ref("");

const categoriaSeleccionada = ref("");

//Agregar Preguntas
const agregarPreg = function () {
    if (nuevaPreg.value !== '' && categoriaSeleccionada.value !== '') {
        const nuevaId = preguntas.value.length + 1;
        preguntas.value.push({ id: nuevaId, categoria: categoriaSeleccionada.value, enunciado: nuevaPreg.value });
        nuevaPreg.value = '';
        localStorage.setItem("Preguntas", JSON.stringify(preguntas.value));
    }
};

//Eliminar Preguntas por ID
const borrarPreguntaID = function (id) {
    preguntas.value = preguntas.value.filter(pregunta => pregunta.id !== id);
    localStorage.setItem("Preguntas", JSON.stringify(preguntas.value));
};

//Mostrar Preguntas
function mostrarPreg() {
    //Así se cambia entre true y false, simulando un toogle.
    mostrar.value = !mostrar.value;
}

console.log(categorias.value);

</script>

<template>
    <main>
        <h1>Preguntas de exámen:</h1>
        <div v-if="mostrar" class="contentP">
            <div v-for="preg in preguntas" :key="preg.id">
                <p>{{ preg.id }}. ({{ preg.categoria }}) : {{ preg.enunciado }}</p>
                <button @click="borrarPreguntaID(preg.id)">Borrar</button>
                <hr>
            </div>
        </div>
        <br>
        <form @submit.prevent="agregarPreg" class="formulario">
            <label for="nuevaPreg">Nueva Pregunta:</label>
            <br>
            <input type="text" v-model="nuevaPreg" id="nuevaPreg" required />
            <select v-model="categoriaSeleccionada">
                <option v-for="cat in categorias" :key="cat.id" :value="cat.categoria">{{ cat.categoria }}</option>
            </select>
            <br>
            <button type="submit">Agregar</button>
        </form>
        <button type="button" @click="mostrarPreg">Mostrar Preguntas</button>
        <br>
        <!-- <button class="eliminar" @click="eliminarPreg">Eliminar Preguntas</button> -->
    </main>
</template>

<style scoped>
main {
    background-color: beige;
}

h1 {
    margin: 0;
    margin-left: 1rem;
}

.contentP {
    margin: 1rem;
    padding: 1rem;
    border: 2px dotted red;
    width: 35%;
}

form {
    padding: 1rem;
}

.eliminar {
    margin: 1rem;
}
</style>
