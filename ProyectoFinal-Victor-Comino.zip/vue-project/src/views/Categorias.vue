<script setup>
import { ref } from 'vue';

//Variables 
const categorias = ref([
  { id: 1, categoria: 'Matemáticas' },
]);


//Guardado en JSON
const listaCategoriasGuardadas = JSON.parse(localStorage.getItem("Categorias"));
if (listaCategoriasGuardadas) {
  categorias.value = listaCategoriasGuardadas;
}

const nuevaCatego = ref("");

//Métodos
//Agregar Categoría
const agregarCatego = function () {
  if (nuevaCatego.value !== '') {
    const nuevaId = categorias.value.length + 1;
    categorias.value.push({ id: nuevaId, categoria: nuevaCatego.value });
    nuevaCatego.value = '';
    localStorage.setItem("Categorias", JSON.stringify(categorias.value));
  }
};

//Eliminar Categorías
const eliminarCategorias = function () {
  categorias.value = [];
  localStorage.removeItem("Categorias");
}

//Eliminar Categoría por ID
const borrarCategoriaID = function (id) {
  categorias.value = categorias.value.filter(categoria => categoria.id !== id);
  localStorage.setItem("Categorias", JSON.stringify(categorias.value));
};

</script>

<template>
  <main>
    <h1>Categorías de exámenes:</h1>
    <div class="contentC">
      <div v-for="catego in categorias" :key="catego.id">
        <p>{{ catego.id }}. {{ catego.categoria }}</p>

        <button @click="borrarCategoriaID(catego.id)">Borrar</button>
        <hr>
      </div>
    </div>
    <br>
    <form @submit.prevent="agregarCatego" class="formulario">
      <label for="nuevaCatego">Nueva Categoría:</label>
      <input type="text" v-model="nuevaCatego" id="nuevaCatego" required />
      <button type="submit">Agregar</button>
    </form>
    <br>
    <button class="eliminar" @click="eliminarCategorias">Eliminar Tareas</button>
  </main>
</template>

<style scoped>
main {
  background-color: beige;
}

h1 {
  margin: 0;
  margin-left: 1rem;
}

.contentC {
  margin: 1rem;
  padding: 1rem;
  border: 2px dotted red;
  width: 35%;
}

form {
  padding: 1rem;
}

.eliminar {
  margin: 1rem;
}
</style>