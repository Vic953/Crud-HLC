<script setup>
import { ref } from 'vue'

const datosSesionGlobal = ref({
  nombre: '',
  contraseña: '',
  rol: ''
})

const recuperarDatos = function () {
  datosSesionGlobal.value.nombre = localStorage.getItem('sesionN')
  datosSesionGlobal.value.contraseña = localStorage.getItem('sesionC')
  datosSesionGlobal.value.rol = localStorage.getItem('sesionR')
}
recuperarDatos()
</script>

<template>
  <main>
    <div class="content">
      <h1>!Bienvenido a la página principal!</h1>
      <div>
        
        <p>Esta aplicación trata sobre la gestión de examenes y preguntas.</p>
        <p v-if="datosSesionGlobal.nombre && datosSesionGlobal.rol">
          Bienvenido {{ datosSesionGlobal.nombre }}
        </p>
        <p v-else-if="datosSesionGlobal.nombre || datosSesionGlobal.rol">
          Fallo en el loguin
        </p>
        <p v-else>Bienvenido invitado, debes loguearte.</p>
      </div>
      <br />
    </div>
  </main>
</template>

<style scoped>
.content {
  background-color: beige;
  color: black;
  height: 90vh;
}

p {
  margin: 1em;
}

h1 {
  text-align: center;
  margin: 0;
}
</style>
