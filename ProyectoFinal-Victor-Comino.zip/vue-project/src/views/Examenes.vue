<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

// Variables 
const titulo = ref('');
const fecha = ref('');
const exmen = ref([]);

const preguntasRecogidas = JSON.parse(localStorage.getItem('Preguntas'));
const preguntas = ref(preguntasRecogidas);

const router = useRouter();

//Crear exámen
const crearExamen = function () {
    const examenNuevo = {
        titulo: titulo.value,
        fecha: fecha.value
    };

    exmen.value.push(examenNuevo);
    localStorage.setItem("Examen", JSON.stringify(exmen.value));
    router.push('/listaExm');
};

/* console.log(preguntas); */
console.log(preguntas.value.categoria);
</script>

<template>
    <main>
        <div class="contentE">
            <h1>Crear Examen</h1>
            <form @submit.prevent="crearExamen">
                <label for="titulo">Título del Examen:</label>
                <input type="text" id="titulo" v-model="titulo" required />
                <br>
                <label for="fecha">Fecha del Examen:</label>
                <input type="date" id="fecha" v-model="fecha" required />
                <br>
                <h2>Preguntas Disponibles:</h2>
                <div>
                    <div v-for="pregunta in preguntas" :key="pregunta.id">
                        <input type="checkbox" :id="pregunta.id" v-model="pregunta.selected" />
                        <label :for="pregunta.id">({{ pregunta.categoria }}){{ pregunta.enunciado }}</label>
                    </div>
                </div>
                <br>
                <button type="submit">Guardar Examen</button>
            </form>
        </div>
    </main>
</template>
  
<style scoped>
main {
    background-color: beige;
}

h1 {
    margin: 0;
    margin-left: 1rem;
}

.contentE {

    padding: 1rem;

    width: 35%;
}

form {
    padding: 1rem;
}

.eliminar {
    margin: 1rem;
}
</style>
  