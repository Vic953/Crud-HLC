<script setup>
import Cabecera from './components/Cabecera.vue'
import Pie from './components/Pie.vue'
import BarraOptions from './components/BarraOptions.vue'

import { RouterLink, RouterView } from 'vue-router'

import router from './router'
import { ref } from 'vue'

const datosSesionGlobal = ref({
  nombre: '',
  contraseña: '',
  rol: ''
})
const recuperarDatos = function () {
  datosSesionGlobal.value.nombre = localStorage.getItem('sesionN')
  datosSesionGlobal.value.contraseña = localStorage.getItem('sesionC')
  datosSesionGlobal.value.rol = localStorage.getItem('sesionR')
}
recuperarDatos()

function irVista() {
  router.push('login')
  location.reload();
}
</script>

<template>
  <div>
    <Cabecera></Cabecera>
    <BarraOptions v-if="datosSesionGlobal.rol == 'alumno' || datosSesionGlobal.rol == 'profesor'"></BarraOptions>
    <RouterView />

    <Pie></Pie>
  </div>
</template>

<style scoped></style>
