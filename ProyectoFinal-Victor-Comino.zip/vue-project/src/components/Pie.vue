<script setup></script>

<template>
  <footer>
    <p>@Copyright creado por Víctor Comino</p>
  </footer>
</template>

<style scoped>
footer {
  width: 100%;
  background-color: #333;
  color: white;
  padding: 1rem;
  text-align: center;
}
</style>
