<script setup>
import router from '@/router'

import { ref } from 'vue'

const datosSesionGlobal = ref({
    nombre: '',
    contraseña: '',
    rol: ''
})

const recuperarDatos = function () {
    datosSesionGlobal.value.nombre = localStorage.getItem('sesionN')
    datosSesionGlobal.value.contraseña = localStorage.getItem('sesionC')
    datosSesionGlobal.value.rol = localStorage.getItem('sesionR')
}
recuperarDatos()

function irCat() {
    router.push('/cat')
}

function irPreg() {
    router.push('/preg')
}

function irExmP() {
    router.push('/exmP')
}
function irExmA() {
    router.push('/listaExm')
}


</script>

<template>
    <div id="app">
        <div id="botonera">
            <button v-if="datosSesionGlobal.rol === 'profesor'" @click="irCat">Categorías</button>
            <button v-if="datosSesionGlobal.rol === 'profesor'" @click="irPreg">Preguntas</button>
            <button v-if="datosSesionGlobal.rol === 'profesor'" @click="irExmP">Exámenes</button>
            <button v-else @click="irExmA">Exámenes</button>
        </div>
    </div>
</template>

<style scoped>
button {
    border: none;
    margin-right: 1rem;
    margin-left: 1rem;
    border-radius: 5px;
    margin: 0.5rem;
    background-color: aquamarine;
}
#botonera{
    border: 1px solid rgba(0, 0, 0, 0.3);
}

#app {
    background-color: beige;
}
</style>