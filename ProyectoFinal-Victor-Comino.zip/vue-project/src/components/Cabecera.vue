<script setup>
import router from '@/router'
import { ref } from 'vue'

const datosSesionGlobal = ref({
  nombre: '',
  contraseña: '',
  rol: ''
})

const sesionIniciada = ref(false)


function iniciarSesion() {
  router.push('Login')
  sesionIniciada.value = true
  
}

function cerrarSesion() {
  datosSesionGlobal.value.nombre = localStorage.removeItem('sesionN')
  datosSesionGlobal.value.contraseña = localStorage.removeItem('sesionC')
  datosSesionGlobal.value.rol = localStorage.removeItem('sesionR')
  sesionIniciada.value = false
  router.push('/noSes')
  
}
</script>

<template>
  <nav>
    <button v-if="!sesionIniciada" @click="iniciarSesion">Iniciar Sesión</button>
    <button v-else @click="cerrarSesion">Cerrar sesion</button>
  </nav>
</template>

<style scoped>
nav {
  display: flex;
  height: 45px;
  background-color: bisque;
}

button {
  cursor: pointer;
  border: none;
  border-radius: 10px;
  background-color: rgba(0, 128, 0, 0.486);
  margin: 10px;
}
</style>
